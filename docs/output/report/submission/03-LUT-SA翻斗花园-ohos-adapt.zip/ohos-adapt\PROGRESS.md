# P0–P5 落地状态（host 侧 2026-07-26）

| 阶段 | Issue | Host | Board |
|------|-------|------|-------|
| Gate0 PRD+Issues | — | done | — |
| P0 hello | #2 | aarch64 hello 已编 | hdc 空，待板 |
| P1 kernels | #3 | `libtmac_kernels.a` + selftest 已编；nm 无 TVM | selftest 待推 |
| P2 llama | #4 | `llama-cli`/`llama-bench` OHOS 已编 | 推理待板+gguf |
| P3 SA | #5 | `libtmac_sa.so` + IPC/tile stub | samgr 注册待板 |
| P4 QoS | #6 | `qos_policy` + demo 脚本 | 真 QoS API 待板 |
| P5 交付 | #7 | 矩阵/报告/视频稿骨架 | 实测数待填 |

产物目录：`ohos/build/` · `ohos/hello/build/` · `3rdparty/llama.cpp/build-ohos-check/bin/`
