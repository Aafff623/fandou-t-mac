// HAP NAPI bridge stub (phone fallback track, feasibility D7).
// Real NAPI module registers CreateSession/InferTokenBatch for ArkTS.

#include <cstdio>

extern "C" {

int tmac_napi_module_register_stub(void) {
  std::printf("tmac_napi stub: register LUT-SA NAPI module (wire in DevEco HAP)\n");
  return 0;
}

}
