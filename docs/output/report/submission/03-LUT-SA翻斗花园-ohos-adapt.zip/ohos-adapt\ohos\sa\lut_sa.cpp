#include "lut_sa.h"

#include <atomic>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <string>
#include <unordered_map>

namespace tmac_sa {
namespace {

struct Session {
  bool loaded = false;
  std::string model_path;
};

std::mutex g_mu;
std::unordered_map<uint64_t, Session> g_sessions;
std::atomic<uint64_t> g_next{1};

}  // namespace

Status CreateSession(uint64_t* out_session_id) {
  if (!out_session_id) {
    return Status::kInvalid;
  }
  std::lock_guard<std::mutex> lock(g_mu);
  uint64_t id = g_next.fetch_add(1);
  g_sessions.emplace(id, Session{});
  *out_session_id = id;
  return Status::kOk;
}

Status LoadModel(uint64_t session_id, const std::string& model_path) {
  std::lock_guard<std::mutex> lock(g_mu);
  auto it = g_sessions.find(session_id);
  if (it == g_sessions.end()) {
    return Status::kNoSession;
  }
  it->second.model_path = model_path;
  it->second.loaded = true;
  return Status::kOk;
}

Status InferTokenBatch(uint64_t session_id, const char* prompt, char* out_buf, size_t out_cap) {
  if (!prompt || !out_buf || out_cap == 0) {
    return Status::kInvalid;
  }
  std::lock_guard<std::mutex> lock(g_mu);
  auto it = g_sessions.find(session_id);
  if (it == g_sessions.end()) {
    return Status::kNoSession;
  }
  if (!it->second.loaded) {
    return Status::kNotLoaded;
  }
  // Stub: real path wires llama_cpp_init / tiled llama_cpp_compute (P2/P3).
  std::snprintf(out_buf, out_cap, "[tmac_sa stub] echo: %s", prompt);
  return Status::kOk;
}

Status ReleaseSession(uint64_t session_id) {
  std::lock_guard<std::mutex> lock(g_mu);
  return g_sessions.erase(session_id) ? Status::kOk : Status::kNoSession;
}

}  // namespace tmac_sa
