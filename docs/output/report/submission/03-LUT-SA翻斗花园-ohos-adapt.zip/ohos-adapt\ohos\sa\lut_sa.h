#pragma once

#include <cstdint>
#include <string>

namespace tmac_sa {

enum class Status : int32_t {
  kOk = 0,
  kInvalid = 1,
  kNoSession = 2,
  kNotLoaded = 3,
};

// IPC-shaped API (feasibility P3). Stub until samgr wiring on device.
Status CreateSession(uint64_t* out_session_id);
Status LoadModel(uint64_t session_id, const std::string& model_path);
Status InferTokenBatch(uint64_t session_id, const char* prompt, char* out_buf, size_t out_cap);
Status ReleaseSession(uint64_t session_id);

}  // namespace tmac_sa
