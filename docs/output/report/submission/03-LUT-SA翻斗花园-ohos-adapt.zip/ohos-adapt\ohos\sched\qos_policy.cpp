#include "qos_policy.h"

#include <atomic>
#include <cstdio>

namespace tmac_sched {
namespace {
std::atomic<int> g_level{static_cast<int>(QoSLevel::kDefault)};
}

bool SetThreadQoS(QoSLevel level) {
  g_level.store(static_cast<int>(level));
  // Device: call OH_QoS_SetThreadQoS here (P4).
  return true;
}

QoSLevel GetThreadQoS() {
  return static_cast<QoSLevel>(g_level.load());
}

void LogSchedDecision(const char* signal, QoSLevel chosen) {
  std::printf("[tmac_sched] signal=%s -> qos=%d\n", signal ? signal : "?", static_cast<int>(chosen));
}

}  // namespace tmac_sched
