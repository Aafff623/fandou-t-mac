#pragma once

namespace tmac_sched {

enum class QoSLevel {
  kBackground = 0,
  kUtility = 1,
  kDefault = 2,
  kUserInteractive = 3,
};

// Maps to OH_QoS_SetThreadQoS on device; host stub records intent.
bool SetThreadQoS(QoSLevel level);
QoSLevel GetThreadQoS();

// Perception → decision log line for demo.
void LogSchedDecision(const char* signal, QoSLevel chosen);

}  // namespace tmac_sched
