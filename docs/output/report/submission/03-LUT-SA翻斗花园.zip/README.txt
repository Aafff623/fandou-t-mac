LUT-SA · 初赛演示包说明（翻斗花园）

作品名称：LUT-SA
赛题方向：操作系统智能创新
仓库：https://github.com/Aafff623/fandou-t-mac

本 zip 为初赛可提交的源码/说明打包：
1) 竞赛说明与初赛文档草稿（docs/output/report）
2) 方案与赛题知识（docs/knowledge、docs/adr）
3) 上游 T-MAC 计算核心仍在仓库根目录（python/ include/ deploy/ 等）
   完整源码请以 GitHub 仓库为准；复赛将补充 OpenHarmony Native / SystemAbility 可运行演示。

边界声明：初赛阶段系统服务封装以技术方案与架构图为主；鸿蒙侧可运行 Demo 在复赛补齐。
