# Phase 1 · 测试报告

## 1. 测试目的

验证比特级查找表（LUT）相对反量化基线在边缘 CPU 上的吞吐优势，并说明将该能力封装为 OpenHarmony / HarmonyOS 用户态系统服务后的复现与移植路径，支撑作品「系统级 AI 任务效率提升」主张。

## 2. 测试对象与基线

| 项 | 内容 |
|----|------|
| 加速方案 | T-MAC LUT Kernel（本仓二开底座，上游 microsoft/T-MAC） |
| 对比基线 | llama.cpp CPU 路径（反量化类低比特实现） |
| 模型示例 | BitNet-3B；Llama-2-7B（W2 / W4） |
| 数据来源 | 本仓 `docs/profiling_data.md`（公开 profiling，非本队现场实测） |

## 3. 指标定义

| 指标 | 含义 |
|------|------|
| tokens / s | 生成吞吐 |
| NUM_THREADS | 参与计算的 CPU 线程数 |
| TTFT | 首字延迟（复赛补测） |
| 能耗 / 功耗 | 复赛在可测平台补采 |

## 4. 公开对比结果

数据出处：`docs/profiling_data.md`。单位：tokens / sec。

| 模型 | 设备 | 线程 | llama.cpp | T-MAC | 约倍速 |
|------|------|------|-----------|-------|--------|
| BitNet-3B | M2-Ultra | 1 | 6.49 | 22.08 | ~3.4× |
| BitNet-3B | M2-Ultra | 4 | 22.09 | 54.46 | ~2.5× |
| BitNet-3B | Raspberry Pi 5 | 1 | 1.37 | 8.03 | ~5.9× |
| BitNet-3B | Raspberry Pi 5 | 2 | 2.71 | 11.09 | ~4.1× |
| Llama-2-7B (W2) | M2-Ultra | 1 | 3.82 | 16.68 | ~4.4× |
| Llama-2-7B (W2) | AGX Orin | 1 | 0.79 | 4.36 | ~5.5× |

## 5. 复现步骤（公开数据侧）

1. 克隆本仓或上游 T-MAC，按 README 与 `docs/e2e.md` 准备依赖。
2. 按文档转换或获取对应低比特模型。
3. 运行官方或本仓 benchmark，记录 tokens / s 与线程配置。
4. 同配置运行 llama.cpp 基线并制表。

命令以复赛环境固化后写入附录。

## 6. 移植到 OpenHarmony / HarmonyOS 的计划

| 步骤 | 内容 | 阶段 |
|------|------|------|
| 1 | 抽取 LUT Kernel 为 Native 静态 / 动态库，参考 Android 交叉编译经验 | 复赛前期 |
| 2 | DevEco 创建 Native 模块，打通最小推理调用 | 复赛前期 |
| 3 | 封装 SystemAbility，暴露 Load / Infer / Metrics | 复赛中期 |
| 4 | 叠加轻量感知调度；与 llama.cpp 或官方量化路径对照 | 复赛中后期 |
| 5 | 固化本平台 TTFT、tokens / s、（可选）功耗数据 | 复赛提交前 |

## 7. 风险与边界

| 风险 | 说明 |
|------|------|
| 初赛数据非本队设备实测 | 已明确标注来源，不将公开数据表述为「本队板测」 |
| ISA / 内存布局差异 | ARM 鸿蒙设备需适配；优先用户态库，避免未公开内核 API |
| 权限边界 | SystemAbility 能力级别以可申请 / 可演示为准 |